"""
build.py  —  Run this instead of build.bat if your system blocks .bat files
Usage:
    python build.py
"""
import subprocess
import sys
import os

def run(args):
    """Run a command given as a list of arguments (no shell=True, so spaces in paths are safe)."""
    print(f"\n>>> {' '.join(args)}\n")
    result = subprocess.run(args)
    if result.returncode != 0:
        print(f"[ERROR] Command failed: {' '.join(args)}")
        sys.exit(1)

print("=" * 55)
print("  Land Cover Tool  —  Build Script")
print("=" * 55)

# Install dependencies
print("\n[1/2] Installing dependencies...")
run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

# Build executable
print("\n[2/2] Building executable with PyInstaller...")
run([
    sys.executable, "-m", "PyInstaller",
    "--noconfirm", "--onefile", "--windowed",
    "--name", "LandCoverTool",
    # rasterio, fiona, shapely, pyproj all use Cython extensions and
    # hidden submodules (e.g. rasterio.sample, rasterio._shim, fiona.ogrext)
    # that PyInstaller's static analysis misses. --collect-all bundles
    # the entire package including data files, .pyd/.so extensions, etc.
    "--collect-all", "rasterio",
    "--collect-all", "fiona",
    "--collect-all", "shapely",
    "--collect-all", "pyproj",
    # sklearn also has hidden Cython modules (e.g. sklearn.utils._cython_blas)
    "--collect-all", "sklearn",
    "--add-data", f"classify.py{os.pathsep}.",
    "--add-data", f"change.py{os.pathsep}.",
    "--add-data", f"areas.py{os.pathsep}.",
    "--add-data", f"export.py{os.pathsep}.",
    "--add-data", f"preprocess.py{os.pathsep}.",
    "--add-data", f"accuracy.py{os.pathsep}.",
    "main.py",
])

print("\n" + "=" * 55)
print("  ✅  Done!  Executable is in the /dist folder")
print("=" * 55)
